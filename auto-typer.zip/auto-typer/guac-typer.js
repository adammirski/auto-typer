// Guac Typer: types text into a Guacamole remote session as keystrokes.
//
// Runs inside the Guacamole browser tab (as a bookmarklet, or pasted into the
// DevTools console). It finds the active Guacamole.Client through the web
// app's AngularJS injector and sends key events straight down the existing
// connection, so it works for RDP, SSH and VNC, needs no install, and does
// not depend on the remote clipboard being enabled.
//
// Edit this file, then run `python3 build.py` to regenerate bookmarklet.txt
// and install.html.
(function () {
    'use strict';

    var PANEL_ID = 'guac-typer-panel';

    // Clicking the bookmarklet again toggles the panel instead of adding a second one.
    var existing = document.getElementById(PANEL_ID);
    if (existing) {
        existing.style.display = existing.style.display === 'none' ? '' : 'none';
        return;
    }

    var KEYSYM_ENTER = 0xFF0D;
    var KEYSYM_TAB = 0xFF09;
    var MODIFIER_KEYSYMS = [
        0xFFE1, 0xFFE2, // Shift
        0xFFE3, 0xFFE4, // Control
        0xFFE9, 0xFFEA, // Alt
        0xFFE7, 0xFFE8, // Meta
        0xFFEB, 0xFFEC, // Super
        0xFE03          // AltGr
    ];

    // ---------------------------------------------------------------- client

    function getInjector() {
        var ng = window.angular;
        if (!ng) return null;
        var candidates = [document.querySelector('[ng-app]'), document.body, document.documentElement];
        for (var i = 0; i < candidates.length; i++) {
            if (!candidates[i]) continue;
            try {
                var injector = ng.element(candidates[i]).injector();
                if (injector) return injector;
            } catch (e) { /* try the next element */ }
        }
        return null;
    }

    function isOnScreen(managedClient) {
        try {
            var el = managedClient.client.getDisplay().getElement();
            return document.body.contains(el) && el.getClientRects().length > 0;
        } catch (e) {
            return false;
        }
    }

    // Returns the Guacamole.Client to type into, or throws with a message for the student.
    function findClient() {
        var injector = getInjector();
        if (!injector) {
            throw new Error('Guacamole not found. Run this on the Guacamole tab while connected to a VM.');
        }
        var manager;
        try {
            manager = injector.get('guacClientManager');
        } catch (e) {
            throw new Error('This Guacamole version is not supported (no guacClientManager).');
        }

        var stored = manager.getManagedClients() || {};
        var clients = [];
        Object.keys(stored).forEach(function (id) {
            var mc = stored[id];
            if (mc && mc.client && typeof mc.client.sendKeyEvent === 'function') clients.push(mc);
        });
        if (!clients.length) {
            throw new Error('No open connection. Connect to a VM first.');
        }

        // Several connections can be tiled on one page (Guacamole 1.3+); prefer the
        // focused one, then whichever is actually on screen.
        var focused = clients.filter(function (mc) {
            return mc.clientProperties && mc.clientProperties.focused && isOnScreen(mc);
        });
        if (focused.length) return focused[0].client;
        var visible = clients.filter(isOnScreen);
        if (visible.length) return visible[0].client;
        return clients[0].client;
    }

    // X11 keysym for one character. Latin-1 maps directly; everything else uses
    // the Unicode keysym range, which guacd translates for the remote keyboard.
    function keysymFor(ch) {
        if (ch === '\n') return KEYSYM_ENTER;
        if (ch === '\t') return KEYSYM_TAB;
        var cp = ch.codePointAt(0);
        if ((cp >= 0x20 && cp <= 0x7E) || (cp >= 0xA0 && cp <= 0xFF)) return cp;
        return 0x01000000 | cp;
    }

    // ---------------------------------------------------------------- text

    // Web pages and PDFs often hand you characters that shells reject.
    function cleanText(text, opts) {
        text = text.replace(/\r\n?/g, '\n');
        if (opts.fixQuotes) {
            text = text
                .replace(/[‘’‚‛′]/g, "'")
                .replace(/[“”„‟″]/g, '"')
                .replace(/[‐‑‒–—―−]/g, '-')
                .replace(/…/g, '...')
                .replace(/[   ]/g, ' ')
                .replace(/[​‌‍⁠﻿]/g, '');
        }
        // A real Tab triggers shell auto-completion, so spaces are the safe default.
        if (opts.tabsToSpaces) text = text.replace(/\t/g, '    ');
        text = text.replace(/\n+$/, '');
        if (opts.enterAtEnd) text += '\n';
        return text;
    }

    function sleep(ms) {
        return new Promise(function (resolve) { setTimeout(resolve, ms); });
    }

    // ---------------------------------------------------------------- UI

    var panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.innerHTML =
        '<style>' +
        '#' + PANEL_ID + '{position:fixed;right:16px;bottom:16px;width:380px;max-width:calc(100vw - 32px);z-index:2147483647;' +
        'background:#1e2229;color:#e8eaed;font:13px/1.4 system-ui,-apple-system,Segoe UI,sans-serif;border:1px solid #3c4350;' +
        'border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.45);text-align:left}' +
        '#' + PANEL_ID + ' *{box-sizing:border-box;font:inherit;color:inherit}' +
        '#' + PANEL_ID + ' .gt-head{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;' +
        'background:#2a2f38;border-radius:8px 8px 0 0;cursor:move;user-select:none;font-weight:600}' +
        '#' + PANEL_ID + ' .gt-body{padding:10px 12px 12px}' +
        '#' + PANEL_ID + ' textarea{width:100%;height:150px;resize:vertical;background:#11141a;border:1px solid #3c4350;' +
        'border-radius:4px;padding:6px;font:12px/1.35 ui-monospace,Menlo,Consolas,monospace;white-space:pre;color:#e8eaed}' +
        '#' + PANEL_ID + ' .gt-row{display:flex;flex-wrap:wrap;gap:6px 14px;margin-top:8px;align-items:center}' +
        '#' + PANEL_ID + ' input[type=number]{width:64px;background:#11141a;border:1px solid #3c4350;border-radius:4px;padding:2px 4px}' +
        '#' + PANEL_ID + ' label{display:inline-flex;align-items:center;gap:5px;cursor:pointer}' +
        '#' + PANEL_ID + ' button{border:1px solid #3c4350;background:#2a2f38;border-radius:4px;padding:5px 12px;cursor:pointer;' +
        'min-width:0;width:auto;margin:0;box-shadow:none;text-shadow:none;text-transform:none}' +
        '#' + PANEL_ID + ' button:hover{background:#353b46}' +
        '#' + PANEL_ID + ' button.gt-go{background:#1a73e8;border-color:#1a73e8;color:#fff;font-weight:600}' +
        '#' + PANEL_ID + ' button:disabled{opacity:.45;cursor:default}' +
        '#' + PANEL_ID + ' .gt-x{background:none;border:0;padding:0 4px;font-size:18px;line-height:1}' +
        '#' + PANEL_ID + ' .gt-status{margin-top:8px;min-height:18px;color:#9aa0a6}' +
        '#' + PANEL_ID + ' .gt-status.err{color:#f28b82}' +
        '#' + PANEL_ID + ' .gt-status.ok{color:#81c995}' +
        '</style>' +
        '<div class="gt-head"><span>Guac Typer</span><button class="gt-x" title="Close">&times;</button></div>' +
        '<div class="gt-body">' +
        '<textarea spellcheck="false" placeholder="Paste the command or script here (Ctrl+V / Cmd+V)"></textarea>' +
        '<div class="gt-row">' +
        '<label title="Pause after each character">Char delay <input type="number" class="gt-cd" min="0" max="1000" value="15"> ms</label>' +
        '<label title="Pause after each Enter, gives the shell time to catch up">Line delay <input type="number" class="gt-ld" min="0" max="10000" value="250"> ms</label>' +
        '</div>' +
        '<div class="gt-row">' +
        '<label title="Turn curly quotes and long dashes from web pages into plain ASCII"><input type="checkbox" class="gt-q" checked> Fix smart quotes</label>' +
        '<label title="A real Tab triggers shell auto-complete"><input type="checkbox" class="gt-t" checked> Tabs to spaces</label>' +
        '<label title="Press Enter after the last line (runs the command)"><input type="checkbox" class="gt-e"> Enter at end</label>' +
        '</div>' +
        '<div class="gt-row">' +
        '<button class="gt-go">Type it</button>' +
        '<button class="gt-stop" disabled>Stop</button>' +
        '<button class="gt-paste" title="Read your computer\'s clipboard into the box">Paste clipboard</button>' +
        '</div>' +
        '<div class="gt-status">Paste text, click in the VM where it should go, then click Type it.</div>' +
        '</div>';
    document.body.appendChild(panel);

    var $ = function (sel) { return panel.querySelector(sel); };
    var textarea = $('textarea');
    var goBtn = $('.gt-go');
    var stopBtn = $('.gt-stop');
    var statusEl = $('.gt-status');
    var stopRequested = false;
    var typing = false;

    function setStatus(msg, kind) {
        statusEl.textContent = msg;
        statusEl.className = 'gt-status' + (kind ? ' ' + kind : '');
    }

    // Guacamole listens for keys and text input (IME/composition) on the whole
    // document and would forward what you type or paste into this panel to the
    // VM. Window capture runs first, so stopping propagation there keeps it local.
    var KEY_EVENTS = ['keydown', 'keyup', 'keypress', 'beforeinput', 'input',
        'compositionstart', 'compositionupdate', 'compositionend', 'paste', 'copy', 'cut'];
    function isolate(e) {
        if (panel.contains(e.target)) e.stopImmediatePropagation();
    }
    KEY_EVENTS.forEach(function (type) { window.addEventListener(type, isolate, true); });

    function close() {
        stopRequested = true;
        KEY_EVENTS.forEach(function (type) { window.removeEventListener(type, isolate, true); });
        panel.remove();
    }

    // Drag by the header.
    (function () {
        var head = $('.gt-head');
        var dx = 0, dy = 0, dragging = false;
        head.addEventListener('mousedown', function (e) {
            if (e.target.closest('button')) return;
            var r = panel.getBoundingClientRect();
            dragging = true;
            dx = e.clientX - r.left;
            dy = e.clientY - r.top;
            e.preventDefault();
            e.stopPropagation();
        });
        window.addEventListener('mousemove', function (e) {
            if (!dragging) return;
            panel.style.left = Math.max(0, e.clientX - dx) + 'px';
            panel.style.top = Math.max(0, e.clientY - dy) + 'px';
            panel.style.right = 'auto';
            panel.style.bottom = 'auto';
        }, true);
        window.addEventListener('mouseup', function () { dragging = false; }, true);
    })();

    // Keep clicks in the panel away from the remote display's mouse handler.
    ['mousedown', 'mouseup', 'click', 'touchstart', 'wheel'].forEach(function (type) {
        panel.addEventListener(type, function (e) { e.stopPropagation(); });
    });

    $('.gt-x').addEventListener('click', close);
    stopBtn.addEventListener('click', function () { stopRequested = true; });

    $('.gt-paste').addEventListener('click', function () {
        if (!navigator.clipboard || !navigator.clipboard.readText) {
            setStatus('This browser blocks clipboard reading. Click the box and press Ctrl+V / Cmd+V.', 'err');
            return;
        }
        navigator.clipboard.readText().then(function (text) {
            textarea.value = text;
            setStatus('Clipboard loaded (' + text.length + ' characters).');
        }, function () {
            setStatus('Clipboard access was refused. Click the box and press Ctrl+V / Cmd+V.', 'err');
        });
    });

    function intOf(sel, fallback) {
        var n = parseInt($(sel).value, 10);
        return isNaN(n) || n < 0 ? fallback : n;
    }

    goBtn.addEventListener('click', async function () {
        if (typing) return;
        var text = cleanText(textarea.value, {
            fixQuotes: $('.gt-q').checked,
            tabsToSpaces: $('.gt-t').checked,
            enterAtEnd: $('.gt-e').checked
        });
        if (!text) {
            setStatus('Nothing to type. Paste something into the box first.', 'err');
            return;
        }

        var client;
        try {
            client = findClient();
        } catch (e) {
            setStatus(e.message, 'err');
            return;
        }

        var charDelay = intOf('.gt-cd', 15);
        var lineDelay = intOf('.gt-ld', 250);
        var chars = Array.from(text);
        // RDP servers may silently drop characters their keyboard layout lacks.
        var nonAscii = chars.filter(function (c) { return c.codePointAt(0) > 0x7E; }).length;

        typing = true;
        stopRequested = false;
        goBtn.disabled = true;
        stopBtn.disabled = false;
        textarea.blur();

        try {
            // Make sure no modifier is left "held down" on the remote side, or
            // the first letters arrive as Ctrl/Alt shortcuts.
            MODIFIER_KEYSYMS.forEach(function (k) { client.sendKeyEvent(0, k); });

            for (var i = 0; i < chars.length; i++) {
                if (stopRequested) {
                    setStatus('Stopped after ' + i + ' of ' + chars.length + ' characters.', 'err');
                    return;
                }
                var ks = keysymFor(chars[i]);
                client.sendKeyEvent(1, ks);
                client.sendKeyEvent(0, ks);
                if (i % 20 === 0) setStatus('Typing... ' + i + ' / ' + chars.length);
                await sleep(ks === KEYSYM_ENTER ? Math.max(lineDelay, charDelay) : charDelay);
            }
            if (nonAscii) {
                setStatus('Done. Typed ' + chars.length + ' characters, ' + nonAscii +
                    ' of them non-English. Check those arrived; RDP can drop them.', 'err');
            } else {
                setStatus('Done. Typed ' + chars.length + ' characters.', 'ok');
            }
        } catch (e) {
            setStatus('Typing failed: ' + e.message, 'err');
        } finally {
            typing = false;
            goBtn.disabled = false;
            stopBtn.disabled = true;
        }
    });

    // Exposed for automated tests; harmless otherwise.
    window.__guacTyper = { cleanText: cleanText, keysymFor: keysymFor, findClient: findClient };

    textarea.focus();
})();
