# Auto-Typer for Guacamole labs

Copy and paste does not reach the lab VMs through Guacamole. This project types text into the VM as keystrokes.

There are two tools:

| Tool | What it is | Install | Use it when |
|---|---|---|---|
| **Guac Typer** (main) | A bookmark that adds a typing panel to the Guacamole page | None, just a bookmark | Always try this first |
| **Desktop auto-typer** (backup) | A small Python app that presses keys on your computer | Python 3 + `pynput` | The bookmark cannot be used (for example, a locked-down browser) |

## Guac Typer (bookmarklet)

**Setup, once:** open `install.html` in your browser and follow Step 1 (drag the blue button to the bookmarks bar). If dragging does not work, make a new bookmark and paste the contents of `bookmarklet.txt` as its address.

**Every time:**

1. Log in to Guacamole and open your VM.
2. Click the **Guac Typer** bookmark. A dark panel opens in the bottom right corner.
3. Paste your text into the panel's box.
4. Click inside the VM where the text should go.
5. Click **Type it**. Do not use the keyboard until the panel says *Done*.

Click the bookmark again to hide or show the panel.

How it works: it finds the open Guacamole connection inside the page and sends key events directly down that connection. Because of this, it works for RDP, SSH and VNC, on Windows, Mac and Linux, and in Chrome, Edge, Firefox and Safari. It does not need the remote clipboard. Nothing is sent anywhere else.

### Settings

- **Char delay** (default 15 ms): pause after each character. If letters go missing, raise it to 30 to 50.
- **Line delay** (default 250 ms): pause after each Enter. Raise it if a slow command loses the next line.
- **Fix smart quotes** (on): curly quotes `“ ” ‘ ’` and long dashes `– —` from web pages and PDFs become `" ' -`. Bash rejects the curly ones.
- **Tabs to spaces** (on): a real Tab makes bash and PowerShell try to auto-complete.
- **Enter at end** (off): press Enter after the last line, which runs the command. Off so you can check it first.

### Things to know

- **Each line break is an Enter**, so each line runs as soon as it is typed. For long multi-line PowerShell (loops, arrays, ACL code), type it into Notepad, save as `script.ps1`, and run `powershell -ExecutionPolicy Bypass -File .\script.ps1`.
- **Editors may add indentation.** vim: run `:set paste` first. nano: auto-indent is off by default; `Alt+I` toggles it.
- **Non-English letters** (ł, é, ß...) may be dropped by some RDP servers. The panel warns you when your text has them. Commands and scripts are normally plain ASCII, so this rarely matters.
- **Speed** is about 50 characters per second at the default settings. A 3,000 character script takes about a minute.
- **"Guacamole not found"**: you clicked the bookmark on a different tab, or the VM is not connected yet.

## Desktop auto-typer (backup)

Located in `desktop/`. It types into whatever window has focus, so it also works outside Guacamole.

- **Mac:** double-click `run-mac.command`. The first run installs `pynput` (needs internet once). macOS will ask for **Accessibility** permission: System Settings > Privacy & Security > Accessibility, turn on Terminal, then start it again. The Python that comes with macOS has Tk 8.5, and its window does not accept typing on recent macOS. The launcher skips it automatically, so you need either Python from [python.org](https://www.python.org/downloads/) or Homebrew's `brew install python-tk`.
- **Windows:** install Python from [python.org](https://www.python.org/downloads/) (tick "Add python.exe to PATH"), then double-click `run-windows.bat`.

Paste text, click **Start**, then click into the VM during the 5 second countdown. To stop: click Stop, press Esc (Windows/Linux), or move the mouse to the **top-left corner** of the screen (all systems).

## Files

| File | Purpose |
|---|---|
| `guac-typer.js` | Source of the bookmarklet. Edit this one. |
| `build.py` | Run `python3 build.py` after editing the source. Rebuilds the two files below. |
| `bookmarklet.txt` | Generated. The `javascript:` bookmark address. |
| `install.html` | Generated. Student setup page with the drag-to-bookmarks button. Can be shared or hosted as is. |
| `install.template.html` | Template for `install.html`. |
| `desktop/autotyper.py` | Desktop backup app (Tkinter + pynput). |
| `desktop/run-mac.command`, `desktop/run-windows.bat` | Double-click launchers; they set up a private `.venv` on first run. |
| `tests/` | Local Guacamole 1.6 test lab (Docker) and browser tests. |

## For the instructor

- The bookmarklet only reads the Guacamole page the student already has open and sends keystrokes through the student's own session. It needs no server changes and works with `disable-paste` set on the connection.
- It uses the Guacamole web app's `guacClientManager` service, which exists in all 1.x releases. It was tested against **Guacamole 1.6.0** only. If a future upgrade breaks it, the panel shows an error instead of typing; the desktop app still works.
- `install.html` is a single self-contained file. It can be emailed to students, put on Canvas, or hosted on any web server.

## Testing

Tests were run against a local Guacamole 1.6.0 with an SSH target and an xrdp target (with `disable-paste`), in Chromium and WebKit (Safari's engine):

- every printable ASCII character arrives correctly over SSH and RDP, including upper case and all shifted symbols
- smart quotes and dashes are converted; multi-line text runs line by line; tabs become spaces
- typing into the panel does not leak into the VM
- over SSH, non-English characters arrive; this xrdp server dropped them (Windows RDP not tested)
- the desktop app's text cleaning gives the same results as the bookmarklet's

To run the tests again (needs Docker and `pip install playwright && playwright install chromium webkit`):

```
docker compose -f tests/docker-compose.yml up -d
python3 tests/e2e_ssh.py chromium
python3 tests/e2e_rdp.py chromium
docker compose -f tests/docker-compose.yml down
```
