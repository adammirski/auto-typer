#!/usr/bin/env python3
"""Desktop auto-typer: types text into whatever window has keyboard focus.

Fallback for when the Guac Typer bookmarklet cannot be used. It works with any
remote console (Guacamole, VMware, VirtualBox...) because it fakes real
keystrokes at the operating system level.

Run it with run-mac.command or run-windows.bat, or:  python3 autotyper.py
"""
import queue
import re
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from pynput import keyboard, mouse
except ImportError:  # pragma: no cover - shown to the user instead of a traceback
    keyboard = mouse = None

IS_MAC = sys.platform == "darwin"
FAILSAFE_PX = 3  # mouse within this many pixels of the top-left corner stops typing
SHIFT_SETTLE = 0.005  # seconds between Shift and the key, so the remote side sees Shift first

SMART_CHARS = [
    (r"[‘’‚‛′]", "'"),
    (r"[“”„‟″]", '"'),
    (r"[‐‑‒–—―−]", "-"),
    (r"…", "..."),
    (r"[   ]", " "),
    (r"[​‌‍⁠﻿]", ""),
]


def clean_text(text, fix_quotes=True, tabs_to_spaces=True, enter_at_end=False):
    """Same rules as the bookmarklet: plain ASCII punctuation, no Tab
    (it triggers shell auto-complete), trailing newlines only on request."""
    text = re.sub(r"\r\n?", "\n", text)
    if fix_quotes:
        for pattern, repl in SMART_CHARS:
            text = re.sub(pattern, repl, text)
    if tabs_to_spaces:
        text = text.replace("\t", "    ")
    text = text.rstrip("\n")
    if enter_at_end:
        text += "\n"
    return text


def accessibility_ok():
    """macOS silently drops synthetic keystrokes unless the app running Python
    (Terminal, iTerm...) has Accessibility permission."""
    if not IS_MAC:
        return True
    try:
        from ApplicationServices import AXIsProcessTrusted
        return bool(AXIsProcessTrusted())
    except Exception:
        return True  # cannot tell; do not block


def _mac_key_map():
    """char -> (keycode, needs_shift) for the current macOS keyboard layout."""
    from pynput._util.darwin import keycode_context, keycode_to_string
    shift_state = 0x02  # (shiftKey >> 8) & 0xFF, as UCKeyTranslate expects
    result = {}
    with keycode_context() as ctx:
        # Main keys (0-63) before the keypad, unshifted before shifted, so '*'
        # comes from Shift+8 rather than the keypad.
        for codes, state in ((range(64), 0), (range(64), shift_state), (range(64, 128), 0)):
            for code in codes:
                ch = keycode_to_string(ctx, code, state)
                if len(ch) == 1 and ch not in result:
                    result[ch] = (code, bool(state))
    return result


def _windows_key_map():
    """char -> (virtual key, needs_shift) for printable ASCII on the current
    Windows layout. Keys that also need Ctrl or Alt (AltGr) are left out."""
    import ctypes
    scan = ctypes.windll.user32.VkKeyScanW
    scan.restype = ctypes.c_short
    result = {}
    for code in range(0x20, 0x7F):
        res = scan(ctypes.c_wchar(chr(code)))
        if res == -1:
            continue
        vk, mods = res & 0xFF, (res >> 8) & 0xFF
        if mods in (0, 1):
            result[chr(code)] = (vk, mods == 1)
    return result


def key_map():
    """pynput types characters that need Shift as a bare Unicode event (macOS:
    the 'a' key carrying a different letter; Windows: a Unicode packet) and
    never presses Shift. Browsers and Guacamole drop many of those, so we look
    up the real key and press it with a real Shift instead."""
    try:
        if IS_MAC:
            return _mac_key_map()
        if sys.platform == "win32":
            return _windows_key_map()
    except Exception:
        pass
    return {}


class Typer(threading.Thread):
    """Types `text` in the background and reports progress through `events`."""

    def __init__(self, text, countdown, char_delay, line_delay, events):
        super().__init__(daemon=True)
        self.text = text
        self.countdown = countdown
        self.char_delay = char_delay / 1000.0
        self.line_delay = line_delay / 1000.0
        self.events = events
        self.stop_flag = threading.Event()
        self.kb = keyboard.Controller()
        self.mouse = mouse.Controller()
        self.keys = key_map()

    def tap(self, ch):
        if ch not in self.keys:
            self.kb.type(ch)  # no plain key for it (e.g. accented letters)
            return
        vk, shift = self.keys[ch]
        key = keyboard.KeyCode.from_vk(vk)
        if not shift:
            self.kb.press(key)
            self.kb.release(key)
            return
        self.kb.press(keyboard.Key.shift)
        time.sleep(SHIFT_SETTLE)
        self.kb.press(key)
        self.kb.release(key)
        time.sleep(SHIFT_SETTLE)
        self.kb.release(keyboard.Key.shift)

    def stopped(self):
        if self.stop_flag.is_set():
            return True
        try:
            x, y = self.mouse.position
            if x <= FAILSAFE_PX and y <= FAILSAFE_PX:
                self.stop_flag.set()
        except Exception:
            pass
        return self.stop_flag.is_set()

    def run(self):
        for left in range(self.countdown, 0, -1):
            self.events.put(("status", "Click into the VM now. Typing in %d..." % left))
            for _ in range(10):
                if self.stopped():
                    self.events.put(("done", "Cancelled."))
                    return
                time.sleep(0.1)

        # A modifier still held from the click would turn letters into shortcuts.
        for key in (keyboard.Key.shift, keyboard.Key.ctrl, keyboard.Key.alt, keyboard.Key.cmd):
            try:
                self.kb.release(key)
            except Exception:
                pass

        total = len(self.text)
        for i, ch in enumerate(self.text):
            if self.stopped():
                self.events.put(("done", "Stopped after %d of %d characters." % (i, total)))
                return
            if ch == "\n":
                self.kb.press(keyboard.Key.enter)
                self.kb.release(keyboard.Key.enter)
                time.sleep(max(self.line_delay, self.char_delay))
                continue
            if ch == "\t":
                self.kb.press(keyboard.Key.tab)
                self.kb.release(keyboard.Key.tab)
            else:
                self.tap(ch)
            if i % 20 == 0:
                self.events.put(("status", "Typing... %d / %d   (mouse to top-left corner = stop)" % (i, total)))
            time.sleep(self.char_delay)
        self.events.put(("done", "Done. Typed %d characters." % total))


class App:
    def __init__(self, root):
        self.root = root
        self.typer = None
        self.events = queue.Queue()
        self.esc_listener = None

        root.title("Auto-Typer")
        root.minsize(460, 380)
        frame = ttk.Frame(root, padding=10)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="Text to type (paste with Ctrl+V / Cmd+V):").pack(anchor="w")
        self.textbox = tk.Text(frame, height=12, wrap="none", undo=True, font=("Courier", 12))
        self.textbox.pack(fill="both", expand=True, pady=(4, 8))

        opts = ttk.Frame(frame)
        opts.pack(fill="x")
        self.countdown = tk.IntVar(value=5)
        self.char_delay = tk.IntVar(value=20)
        self.line_delay = tk.IntVar(value=250)
        for label, var, hi in (("Countdown s", self.countdown, 30),
                               ("Char delay ms", self.char_delay, 1000),
                               ("Line delay ms", self.line_delay, 10000)):
            ttk.Label(opts, text=label).pack(side="left")
            ttk.Spinbox(opts, from_=0, to=hi, textvariable=var, width=6).pack(side="left", padx=(4, 12))

        checks = ttk.Frame(frame)
        checks.pack(fill="x", pady=6)
        self.fix_quotes = tk.BooleanVar(value=True)
        self.tabs_to_spaces = tk.BooleanVar(value=True)
        self.enter_at_end = tk.BooleanVar(value=False)
        ttk.Checkbutton(checks, text="Fix smart quotes", variable=self.fix_quotes).pack(side="left")
        ttk.Checkbutton(checks, text="Tabs to spaces", variable=self.tabs_to_spaces).pack(side="left", padx=12)
        ttk.Checkbutton(checks, text="Enter at end", variable=self.enter_at_end).pack(side="left")

        buttons = ttk.Frame(frame)
        buttons.pack(fill="x")
        self.start_btn = ttk.Button(buttons, text="Start", command=self.start)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(buttons, text="Stop", command=self.stop, state="disabled")
        self.stop_btn.pack(side="left", padx=6)
        ttk.Button(buttons, text="Paste clipboard", command=self.paste).pack(side="left")
        ttk.Button(buttons, text="Open file...", command=self.open_file).pack(side="left", padx=6)

        self.status = tk.StringVar()
        ttk.Label(frame, textvariable=self.status, wraplength=520).pack(anchor="w", pady=(8, 0))
        stop_hint = "move the mouse to the top-left corner" if IS_MAC else "press Esc or move the mouse to the top-left corner"
        self.status.set("Paste text, click Start, then click into the VM during the countdown. To stop, %s." % stop_hint)

        if not accessibility_ok():
            messagebox.showwarning(
                "Permission needed",
                "macOS is blocking keystrokes from this app.\n\n"
                "Open System Settings > Privacy & Security > Accessibility and turn on "
                "Terminal (or the app you started this from). Then quit and start the auto-typer again.")

        self.root.after(100, self.poll)

    def paste(self):
        try:
            text = self.root.clipboard_get()
        except tk.TclError:
            self.status.set("Clipboard is empty or not text.")
            return
        self.textbox.delete("1.0", "end")
        self.textbox.insert("1.0", text)

    def open_file(self):
        path = filedialog.askopenfilename()
        if not path:
            return
        with open(path, encoding="utf-8", errors="replace") as fh:
            self.textbox.delete("1.0", "end")
            self.textbox.insert("1.0", fh.read())

    def start(self):
        text = clean_text(self.textbox.get("1.0", "end-1c"), self.fix_quotes.get(),
                          self.tabs_to_spaces.get(), self.enter_at_end.get())
        if not text:
            self.status.set("Nothing to type. Paste something first.")
            return
        try:
            countdown, char_delay, line_delay = (max(0, v.get()) for v in
                                                 (self.countdown, self.char_delay, self.line_delay))
        except tk.TclError:
            self.status.set("Delays must be whole numbers.")
            return
        self.typer = Typer(text, countdown, char_delay, line_delay, self.events)
        self.start_btn.state(["disabled"])
        self.stop_btn.state(["!disabled"])
        if not IS_MAC:
            # pynput's global listener fights Tk's event loop on macOS, so Esc is
            # offered only on Windows and Linux; the corner failsafe works everywhere.
            self.esc_listener = keyboard.Listener(on_press=self.on_key)
            self.esc_listener.start()
        self.typer.start()

    def on_key(self, key):
        if key == keyboard.Key.esc and self.typer:
            self.typer.stop_flag.set()

    def stop(self):
        if self.typer:
            self.typer.stop_flag.set()

    def poll(self):
        try:
            while True:
                kind, msg = self.events.get_nowait()
                self.status.set(msg)
                if kind == "done":
                    self.start_btn.state(["!disabled"])
                    self.stop_btn.state(["disabled"])
                    if self.esc_listener:
                        self.esc_listener.stop()
                        self.esc_listener = None
        except queue.Empty:
            pass
        self.root.after(100, self.poll)


def main():
    if keyboard is None:
        print("pynput is not installed. Run:  python3 -m pip install pynput")
        sys.exit(1)
    root = tk.Tk()
    app = App(root)
    # Started from Terminal, the window can open behind it with Terminal still
    # receiving the keyboard. Pull it to the front and focus the text box.
    root.lift()
    root.attributes("-topmost", True)
    root.after(300, lambda: root.attributes("-topmost", False))
    root.focus_force()
    app.textbox.focus_set()
    root.mainloop()


if __name__ == "__main__":
    main()
