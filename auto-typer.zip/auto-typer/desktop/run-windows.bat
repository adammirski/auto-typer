@echo off
rem Double-click to start the auto-typer on Windows. First run sets up a private
rem Python environment next to this file (needs internet once).
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
    echo First run: setting up, about a minute...
    py -3 -m venv .venv || python -m venv .venv || (echo Python 3 is missing. Install it from https://www.python.org/downloads/ & pause & exit /b 1)
    .venv\Scripts\python -m pip install --quiet --upgrade pip
    .venv\Scripts\python -m pip install --quiet -r requirements.txt || (echo Install failed. & pause & exit /b 1)
)
start "" .venv\Scripts\pythonw.exe autotyper.py
