#!/bin/bash
# Double-click to start the auto-typer on macOS. First run sets up a private
# Python environment next to this file (needs internet once).
cd "$(dirname "$0")" || exit 1

# The Python that ships with macOS has Tk 8.5, whose windows do not take keyboard
# input on recent macOS. Prefer any Python whose Tk is 8.6 or newer.
tk_ok() {
    "$1" -c 'import sys, tkinter; sys.exit(0 if tkinter.TkVersion >= 8.6 else 1)' 2>/dev/null
}

if [ -x .venv/bin/python ] && ! tk_ok .venv/bin/python; then
    echo "Rebuilding setup with a newer Python..."
    rm -rf .venv
fi

if [ ! -x .venv/bin/python ]; then
    PY=""
    for candidate in /opt/homebrew/bin/python3 /opt/homebrew/bin/python3.[0-9]* \
                     /usr/local/bin/python3 /usr/local/bin/python3.[0-9]* \
                     /Library/Frameworks/Python.framework/Versions/Current/bin/python3 python3; do
        case "$candidate" in *-config) continue ;; esac
        if command -v "$candidate" >/dev/null 2>&1 && tk_ok "$candidate"; then
            PY="$candidate"
            break
        fi
    done
    if [ -z "$PY" ]; then
        echo "No Python with a working Tk was found."
        echo "Install Python from https://www.python.org/downloads/"
        echo "or with Homebrew:  brew install python-tk"
        read -r
        exit 1
    fi
    echo "First run: setting up with $PY (about a minute)..."
    "$PY" -m venv .venv || { echo "Could not create the Python environment."; read -r; exit 1; }
    .venv/bin/python -m pip install --quiet --upgrade pip
    .venv/bin/python -m pip install --quiet -r requirements.txt || { echo "Install failed."; read -r; exit 1; }
fi
exec .venv/bin/python autotyper.py
