#!/usr/bin/env python3
"""Build bookmarklet.txt and install.html from guac-typer.js.

Usage: python3 build.py
"""
import html
import re
from pathlib import Path
from urllib.parse import quote

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "guac-typer.js"
BOOKMARKLET = HERE / "bookmarklet.txt"
INSTALL_PAGE = HERE / "install.html"
TEMPLATE = HERE / "install.template.html"


def shrink(js: str) -> str:
    """Drop whole-line comments, blank lines and indentation. Newlines stay, so
    trailing comments and statements without semicolons remain valid."""
    lines = []
    for line in js.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("//"):
            continue
        lines.append(stripped)
    return "\n".join(lines)


def main() -> None:
    js = shrink(SOURCE.read_text(encoding="utf-8"))
    # Encode everything except unreserved characters, so the URL is safe both in
    # a bookmark's address field and inside an HTML attribute.
    url = "javascript:" + quote(js, safe="")
    BOOKMARKLET.write_text(url + "\n", encoding="utf-8")

    page = TEMPLATE.read_text(encoding="utf-8")
    page = page.replace("{{BOOKMARKLET_HREF}}", html.escape(url, quote=True))
    page = page.replace("{{BOOKMARKLET_TEXT}}", html.escape(url))
    page = page.replace("{{SIZE_KB}}", f"{len(url) / 1024:.1f}")
    if re.search(r"\{\{[A-Z_]+\}\}", page):
        raise SystemExit("install.template.html has an unfilled placeholder")
    INSTALL_PAGE.write_text(page, encoding="utf-8")

    print(f"bookmarklet.txt  {len(url):,} characters")
    print(f"install.html     written")


if __name__ == "__main__":
    main()
