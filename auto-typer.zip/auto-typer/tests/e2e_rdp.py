import subprocess, sys, time, urllib.parse
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
from playwright.sync_api import sync_playwright
BROWSER = sys.argv[1] if len(sys.argv) > 1 else "chromium"
js = urllib.parse.unquote(open(ROOT / "bookmarklet.txt").read().strip()[len("javascript:"):])
def sh(cmd, user="root"):
    return subprocess.run(["docker", "exec", "-u", user, "rdptarget", "sh", "-c", cmd], capture_output=True, text=True).stdout
sh("rm -f /tmp/rdp.txt")
with sync_playwright() as p:
    b = getattr(p, BROWSER).launch()
    pg = b.new_page(viewport={"width": 1280, "height": 800})
    pg.goto("http://localhost:18080/guacamole/")
    pg.fill("input[name=username]", "rdpstudent"); pg.fill("input[name=password]", "student")
    pg.click("input[type=submit], button[type=submit]")
    pg.wait_for_timeout(2500)
    if "/client/" not in pg.url: pg.click("text=rdp-target")
    pg.wait_for_selector(".display canvas", timeout=30000)
    pg.wait_for_timeout(12000)
    disp = sh("ls /tmp/.X11-unix").split()
    print("X displays:", disp)
    d = ":" + [x for x in disp if x != "X0"][-1].lstrip("X") if len(disp) > 0 else ":10"
    subprocess.Popen(["docker", "exec", "-u", "ubuntu", "-e", "DISPLAY=" + d, "rdptarget", "xfce4-terminal"])
    pg.wait_for_timeout(5000)
    pg.evaluate(js)
    pg.fill("#guac-typer-panel textarea", "echo 'Hello World! @#$%^&*()_+{}|:<>? ~`=[]\;,./ ABCxyz 0123' > /tmp/rdp.txt")
    pg.check("#guac-typer-panel .gt-e")
    pg.click("#guac-typer-panel .gt-go")
    pg.wait_for_function("document.querySelector('#guac-typer-panel .gt-status').textContent.startsWith('Done')", timeout=60000)
    pg.wait_for_timeout(2000)
    pg.screenshot(path=str(ROOT / "tests" / ("shot-rdp-%s.png" % BROWSER)))
    b.close()
out = sh("cat /tmp/rdp.txt")
exp = "Hello World! @#$%^&*()_+{}|:<>? ~`=[]\;,./ ABCxyz 0123\n"
print("rdp out:", repr(out)); print("rdp ok:", out == exp)
