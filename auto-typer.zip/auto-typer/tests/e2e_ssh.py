import subprocess, sys, time, urllib.parse
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
from playwright.sync_api import sync_playwright

BROWSER = sys.argv[1] if len(sys.argv) > 1 else "chromium"
js = urllib.parse.unquote(open(ROOT / "bookmarklet.txt").read().strip()[len("javascript:"):])

def sh(cmd):
    return subprocess.run(["docker", "exec", "sshtarget", "sh", "-c", cmd], capture_output=True, text=True).stdout

sh("rm -f /tmp/out1.txt /tmp/out2.txt")
EXPECT1 = 'He said "hi" & $HOME ~ | <> {} [] \\ `x` ł ż é ÄÖÜ \'quoted\' - A-Z 123'
with sync_playwright() as p:
    b = getattr(p, BROWSER).launch()
    pg = b.new_page(viewport={"width": 1280, "height": 800})
    pg.goto("http://localhost:18080/guacamole/")
    pg.fill("input[name=username]", "student")
    pg.fill("input[name=password]", "student")
    pg.click("input[type=submit], button[type=submit]")
    pg.wait_for_timeout(2500)
    if "/client/" not in pg.url:
        pg.click("text=ssh-target")
    pg.wait_for_selector(".display canvas", timeout=20000)
    pg.wait_for_timeout(4000)  # shell prompt

    pg.evaluate(js)
    print("panel present:", pg.locator("#guac-typer-panel").count())

    # Key isolation: typing in the panel must not reach the VM.
    pg.click("#guac-typer-panel textarea")
    pg.keyboard.type("zzz LEAK ")
    pg.keyboard.press("Enter")
    pg.wait_for_timeout(500)

    # Smart quotes / en dash / tab should be normalised; Enter at end runs it.
    cmd1 = "echo “He said \\\"hi\\\" & $HOME ~ | <> {} [] \\\\ \\`x\\` ł ż é ÄÖÜ ‘quoted’ – A-Z 123” > /tmp/out1.txt\n"
    pg.fill("#guac-typer-panel textarea", cmd1)
    pg.check("#guac-typer-panel .gt-e")
    t = time.time()
    pg.click("#guac-typer-panel .gt-go")
    pg.wait_for_function("document.querySelector('#guac-typer-panel .gt-status').textContent.startsWith('Done')", timeout=60000)
    print("typed in %.1fs" % (time.time() - t))

    # Multi-line: each line runs on its own.
    pg.fill("#guac-typer-panel textarea", "echo line1 > /tmp/out2.txt\n\techo LINE2 >> /tmp/out2.txt")
    pg.click("#guac-typer-panel .gt-go")
    pg.wait_for_function("document.querySelector('#guac-typer-panel .gt-status').textContent.startsWith('Done')", timeout=60000)
    pg.wait_for_timeout(1500)
    pg.screenshot(path=str(ROOT / "tests" / ("shot-ssh-%s.png" % BROWSER)))

    # Bookmarklet toggle.
    pg.evaluate(js)
    print("hidden after 2nd click:", pg.evaluate("document.getElementById('guac-typer-panel').style.display"))
    b.close()

out1 = sh("cat /tmp/out1.txt").rstrip("\n")
out2 = sh("cat /tmp/out2.txt")
home = sh("echo $HOME").strip()
exp1 = EXPECT1.replace("$HOME", "/config")
print("out1:", repr(out1))
print("out1 ok:", out1 == exp1 or out1 == EXPECT1.replace("$HOME", home))
print("out2:", repr(out2), "ok:", out2 == "line1\nLINE2\n")
